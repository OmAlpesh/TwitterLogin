//
//  ViewController.swift
//  LoginWithTwitterSwift3
//

//

import UIKit
import TwitterKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    
        let logInButton = TWTRLogInButton { (session, error) in
            if let unwrappedSession = session {
                let alert = UIAlertController(title: "Logged In",
                                              message: "User \(unwrappedSession.userName) has logged in",
                    preferredStyle: UIAlertControllerStyle.alert
                )
                alert.addAction(UIAlertAction(title: "OK", style: UIAlertActionStyle.default, handler: nil))
                self.present(alert, animated: true, completion: nil)
            } else {
                NSLog("Login error: %@", error!.localizedDescription);
            }
        }
        
        // TODO: Change where the log in button is positioned in your view
        logInButton.center = self.view.center
        self.view.addSubview(logInButton)
        
//        // Add a button to the center of the view to show the timeline
//        let button = UIButton(type: .system)
//        button.setTitle("Show Timeline", for: .normal)
//        button.sizeToFit()
//        button.center = view.center
//        button.addTarget(self, action: #selector(showTimeline), for: [.touchUpInside])
//        view.addSubview(button)
        
    }
    
    
    @IBAction func showTimeLine(_ sender: Any) {
        showTimeline()
    }
    
    @IBAction func btnNewTwit(_ sender: Any) {
        sendTwit()
    }
    
    func showTimeline() {
        // Create an API client and data source to fetch Tweets for the timeline
        let client = TWTRAPIClient()
        //TODO: Replace with your collection id or a different data source
        
        let dataSource = TWTRCollectionTimelineDataSource(collectionID: "539487832448843776", apiClient: client)
    
        //let dataSource = TWTRUserTimelineDataSource(screenName: "fabric", apiClient: client)
        
        // Create the timeline view controller
        let timelineViewControlller = TWTRTimelineViewController(dataSource: dataSource)
        // Create done button to dismiss the view controller
        let button = UIBarButtonItem(barButtonSystemItem: .done, target: self, action: #selector(dismissTimeline))
        timelineViewControlller.navigationItem.leftBarButtonItem = button
        // Create a navigation controller to hold the
        let navigationController = UINavigationController(rootViewController: timelineViewControlller)
        showDetailViewController(navigationController, sender: self)
    }
    
    func dismissTimeline() {
        dismiss(animated: true, completion: nil)
    }

    /*
    func twitNew()  {
        // TODO: Base this Tweet ID on some data from elsewhere in your app
        TWTRAPIClient().loadTweet(withID: "3219087739") { (tweet, error) in
            if let unwrappedTweet = tweet {
                let tweetView = TWTRTweetView(tweet: unwrappedTweet)
                tweetView.center = CGPoint(x: self.view.center.x, y:  self.topLayoutGuide.length + tweetView.frame.size.height / 2)
                self.view.addSubview(tweetView)
            } else {
                NSLog("Tweet load error: %@", error!.localizedDescription);
            }
        }
    }
 */

    func sendTwit()  {
        let userID: String =  (Twitter.sharedInstance().sessionStore.session()?.userID)! as String
        
        let composer: TWTRComposer = TWTRComposer()
        
        composer.setText("HelloTwit")
        composer.setImage(UIImage(named: ""))
        
        composer.show(from: self, completion: {(_ result: TWTRComposerResult) -> Void in
            
            if result == TWTRComposerResult.cancelled {
                print("Tweet composition cancelled")
            }
            else {
                print("Sending Tweet!")
            }
        })
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

